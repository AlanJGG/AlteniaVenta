// start:ng42.barrel
export { Header1 } from "./Header1";
export { Header2 } from "./Header2";
// end:ng42.barrel

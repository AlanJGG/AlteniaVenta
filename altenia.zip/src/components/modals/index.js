// start:ng42.barrel
export { ModalClientes } from "./ModalClientes";
export { ModalGastos } from "./ModalGastos";
// end:ng42.barrel

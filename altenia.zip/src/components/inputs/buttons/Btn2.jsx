export const Btn2 = ({ title, onClick }) => {
  return (
    <button type="button" className="btn2" onClick={onClick}>
      {title}
    </button>
  );
};

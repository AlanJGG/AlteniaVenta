// start:ng42.barrel
// end:ng42.barrel
